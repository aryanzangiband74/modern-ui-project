import google from "../../assets/google.png";
import shopify from "../../assets/shopify.png";
import dropbox from "../../assets/dropbox.png";
import slack from "../../assets/slack.png";
import atlassian from "../../assets/atlassian.png";
export { google, shopify, dropbox, slack, atlassian };
